/**
 * This package is used to persist domain objects to the database.
 */
package com.qa.ims.persistence.domain;