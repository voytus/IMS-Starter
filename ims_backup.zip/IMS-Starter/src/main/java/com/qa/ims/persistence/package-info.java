/**
 * This package is used to persistence entities to the database.
 */
package com.qa.ims.persistence;